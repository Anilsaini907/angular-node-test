import { Component } from '@angular/core';
import { TutorialService } from './services/tutorial.service';
import { Router } from '@angular/router';
import {HttpParams} from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tutorialapp';
  users: any=[];
 filterBy:any;
  constructor(private tutorialservices: TutorialService,private router : Router) { }

  filter() {
     console.log(this.filterBy);
    // this.tutorialservices.getAll().subscribe(res=>{console.log(res)});
  }
}
