import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { TutorialService } from 'src/app/services/tutorial.service';
import { Router , ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-tutorial-details',
  templateUrl: './tutorial-details.component.html',
  styleUrls: ['./tutorial-details.component.css']
})
export class TutorialDetailsComponent implements OnInit {
  profileForm:any=FormGroup;
  constructor(private tutorialservices: TutorialService,private router: Router, private activatedRoute: ActivatedRoute) { }
   title:string="";
   description:string="";
   published:number=0;
   id:any;
   message:string="";
   showsuccess:boolean=false;
  ngOnInit(): void {
    this.id=this.activatedRoute.snapshot.url[1].path;
    console.log(this.activatedRoute.snapshot.url[1].path);
    this.tutorialservices.get(this.activatedRoute.snapshot.url[1].path).subscribe(
      res => {
        const titl = document.getElementById('title') as HTMLInputElement
        titl.value=res.title;
        const descriptio = document.getElementById('description') as HTMLInputElement
        descriptio.value=res.description;
        const publishe = document.getElementById('published') as HTMLInputElement
        publishe.value=res.published;
        console.log(res.title);});


    this.profileForm = new FormGroup({
      title: new FormControl(''),
      description: new FormControl(''),
      published: new FormControl(''),
    });
  }

  onSubmit() {
    this.tutorialservices.update(this.id,this.profileForm.value).subscribe(
     res => {console.log(res);
      if(res.status===200){
        this.profileForm.reset();
        this.message=res.message;
        this.showsuccess=true;
        // this.router.navigate(['/tutorials'])
       }
    });
     
     
   // console.warn(this.profileForm.value);
 }

}
