import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { TutorialService } from 'src/app/services/tutorial.service';

@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.component.html',
  styleUrls: ['./add-tutorial.component.css']
})
export class AddTutorialComponent implements OnInit {
  message:string="";
   showsuccess:boolean=false;
  constructor(private tutorialservices: TutorialService,private router: Router,) { }
  profileForm:any=FormGroup;
  ngOnInit(): void {
   
    this.profileForm = new FormGroup({
      title: new FormControl(''),
      description: new FormControl(''),
      published: new FormControl(''),
    });

    
  }
  onSubmit() {
     this.tutorialservices.create(this.profileForm.value).subscribe(
      res => {console.log(res);
        if(res.status===200){
          this.profileForm.reset();
          this.message=res.message;
          this.showsuccess=true;
          // this.router.navigate(['/tutorials'])
         }});
    // console.warn(this.profileForm.value);
  }

}
