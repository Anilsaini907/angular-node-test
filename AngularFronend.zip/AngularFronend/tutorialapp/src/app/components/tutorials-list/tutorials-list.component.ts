import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs';
import { filter } from "rxjs/operators";
import { TutorialService } from 'src/app/services/tutorial.service';

@Component({
  selector: 'app-tutorials-list',
  templateUrl: './tutorials-list.component.html',
  styleUrls: ['./tutorials-list.component.css']
})
export class TutorialsListComponent implements OnInit {
  constructor(private tutorialservices: TutorialService) { }
  tutorials:any = [];
  filterBy:any;
  message:string="";
  showsuccess:boolean=false;

  ngOnInit(): void {
   this.tutorialservices.getAll().subscribe( data => {
      this.tutorials = data;
      console.log(data);
    });
  }

  filter() {
    this.filterBy = this.filterBy.toLocaleLowerCase();
    console.log( this.filterBy);
    this.tutorialservices.findByTitle(this.filterBy).subscribe(val => {
        console.log(val);
        if(val.length===0){
          this.showsuccess=true;
          this.message="No result found for your search please try with another keyword."
        }
        this.tutorials = val;
      });
}
}