import { Component, OnInit } from '@angular/core';
import { TutorialService } from 'src/app/services/tutorial.service';

@Component({
  selector: 'app-tutorials-list',
  templateUrl: './tutorials-list.component.html',
  styleUrls: ['./tutorials-list.component.css']
})
export class TutorialsListComponent implements OnInit {
  tutorials:any = [];

  filterBy:any;
 

  filter() {
     console.log(this.filterBy);
  
  }

  constructor(private tutorialservices: TutorialService) { }

  ngOnInit(): void {
   this.tutorialservices.getAll().subscribe( data => {
      this.tutorials = data;
      console.log(data);
    });
  }

}
